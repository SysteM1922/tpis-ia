# TPI-2-of-2023

Localização do repositório upstream:
https://github.com/lsl0pes/TPI-2-of-2023

Comandos para obter actualizações

-- git remote add upstream git@github.com:lsl0pes/TPI-2-of-2023.git  (só uma vez)

-- git fetch upstream

-- git checkout main

-- git merge --allow-unrelated-histories upstream/main

